package com.pruebaTP.prueba_restfull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaRestfullApplicationTests {

	@Test
	void contextLoads() {
	}

}
