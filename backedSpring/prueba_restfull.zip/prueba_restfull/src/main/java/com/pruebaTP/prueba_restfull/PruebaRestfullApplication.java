package com.pruebaTP.prueba_restfull;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaRestfullApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaRestfullApplication.class, args);
	}

}
