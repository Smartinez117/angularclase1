package resfullEstudiante.restFullEstudiante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestFullEstudianteApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestFullEstudianteApplication.class, args);
	}

}
