package prueba.pruebaFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaFinalApplication.class, args);
	}

}
