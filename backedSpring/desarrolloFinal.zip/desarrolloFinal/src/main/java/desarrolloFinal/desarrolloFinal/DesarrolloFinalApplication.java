package desarrolloFinal.desarrolloFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesarrolloFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesarrolloFinalApplication.class, args);
	}

}
